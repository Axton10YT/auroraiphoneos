import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var auth: AuthViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                if let user = auth.currentUser {
                    Section("Account") {
                        LabeledContent("Name", value: user.display_name)
                        LabeledContent("Email", value: user.email)
                        LabeledContent("2FA", value: user.totp_enabled ? "On" : "Off")
                    }
                }
                Section {
                    Button("Sign out", role: .destructive) {
                        Task {
                            await auth.logout()
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
