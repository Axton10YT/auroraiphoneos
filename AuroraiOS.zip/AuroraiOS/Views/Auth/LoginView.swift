import SwiftUI

struct LoginView: View {
    @EnvironmentObject var auth: AuthViewModel

    @State private var email = ""
    @State private var password = ""
    @State private var displayName = ""
    @State private var mfaCode = ""
    @State private var isSignupMode = false
    @State private var signupConfirmationShown = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    header

                    if auth.pendingMFAChallenge != nil {
                        mfaForm
                    } else if signupConfirmationShown {
                        confirmationBanner
                    } else {
                        credentialsForm
                    }

                    if let error = auth.errorMessage {
                        Text(error)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(24)
                .padding(.top, 40)
            }
            .background(Color(.systemBackground))
        }
    }

    private var header: some View {
        VStack(spacing: 6) {
            Text("Aurora")
                .font(.system(size: 34, weight: .bold, design: .rounded))
            Text("by MeTal")
                .font(.caption)
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
                .kerning(1.2)
        }
    }

    private var credentialsForm: some View {
        VStack(spacing: 16) {
            if isSignupMode {
                TextField("Display name (optional)", text: $displayName)
                    .textFieldStyle(.roundedBorder)
                    .textContentType(.name)
            }
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .textContentType(.emailAddress)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
            SecureField("Password", text: $password)
                .textFieldStyle(.roundedBorder)
                .textContentType(isSignupMode ? .newPassword : .password)

            Button {
                Task {
                    if isSignupMode {
                        let ok = await auth.signup(email: email, password: password, displayName: displayName)
                        if ok { signupConfirmationShown = true }
                    } else {
                        await auth.login(email: email, password: password)
                    }
                }
            } label: {
                if auth.isLoading {
                    ProgressView().frame(maxWidth: .infinity)
                } else {
                    Text(isSignupMode ? "Create account" : "Sign in")
                        .frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(email.isEmpty || password.isEmpty || auth.isLoading)

            Button(isSignupMode ? "Already have an account? Sign in" : "New here? Create an account") {
                isSignupMode.toggle()
                auth.errorMessage = nil
            }
            .font(.footnote)
        }
    }

    private var mfaForm: some View {
        VStack(spacing: 16) {
            Text("Enter the 6-digit code from your authenticator app.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            TextField("123456", text: $mfaCode)
                .textFieldStyle(.roundedBorder)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.center)
                .font(.system(.title3, design: .monospaced))
            Button {
                Task { await auth.submitMFACode(mfaCode) }
            } label: {
                if auth.isLoading {
                    ProgressView().frame(maxWidth: .infinity)
                } else {
                    Text("Verify").frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(mfaCode.count != 6 || auth.isLoading)
        }
    }

    private var confirmationBanner: some View {
        VStack(spacing: 12) {
            Image(systemName: "envelope.badge")
                .font(.largeTitle)
                .foregroundStyle(.blue)
            Text("Check your email")
                .font(.headline)
            Text("We sent a verification link to \(email). Verify, then sign in.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button("Back to sign in") {
                signupConfirmationShown = false
                isSignupMode = false
            }
            .font(.footnote)
        }
    }
}

#Preview {
    LoginView().environmentObject(AuthViewModel())
}
