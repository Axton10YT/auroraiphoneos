import SwiftUI

struct ChatView: View {
    @StateObject private var vm: ChatViewModel
    @State private var draft = ""
    @FocusState private var inputFocused: Bool

    init(conversation: Conversation) {
        _vm = StateObject(wrappedValue: ChatViewModel(conversation: conversation))
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(vm.messages) { message in
                            MessageBubble(message: message)
                                .id(message.id)
                        }
                        if let status = vm.activityStatus {
                            HStack {
                                ProgressView().controlSize(.small)
                                Text(status)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Spacer()
                            }
                            .padding(.horizontal, 4)
                        }
                    }
                    .padding(16)
                }
                .onChange(of: vm.messages.count) {
                    scrollToBottom(proxy)
                }
                .onChange(of: vm.messages.last?.content) {
                    scrollToBottom(proxy)
                }
            }

            Divider()
            inputBar
        }
        .navigationTitle(vm.conversation.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Picker("Model", selection: $vm.selectedModel) {
                        ForEach(AuroraModel.allCases) { model in
                            Text(model.displayName).tag(model)
                        }
                    }
                } label: {
                    Label(vm.selectedModel.displayName, systemImage: "cpu")
                        .font(.caption)
                }
            }
        }
        .task {
            await vm.loadHistory()
        }
        .alert("Error", isPresented: .constant(vm.errorMessage != nil)) {
            Button("OK") { vm.errorMessage = nil }
        } message: {
            Text(vm.errorMessage ?? "")
        }
    }

    private var inputBar: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Message Aurora", text: $draft, axis: .vertical)
                .textFieldStyle(.plain)
                .lineLimit(1...6)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .fill(Color(.secondarySystemBackground))
                )
                .focused($inputFocused)

            Button {
                let text = draft
                draft = ""
                vm.send(text)
            } label: {
                Image(systemName: vm.isSending ? "stop.circle.fill" : "arrow.up.circle.fill")
                    .font(.system(size: 30))
            }
            .disabled(draft.trimmingCharacters(in: .whitespaces).isEmpty && !vm.isSending)
            .onChange(of: vm.isSending) { _, sending in
                // Tapping while sending cancels the stream instead.
            }
        }
        .padding(12)
    }

    private func scrollToBottom(_ proxy: ScrollViewProxy) {
        guard let lastId = vm.messages.last?.id else { return }
        withAnimation(.easeOut(duration: 0.2)) {
            proxy.scrollTo(lastId, anchor: .bottom)
        }
    }
}
