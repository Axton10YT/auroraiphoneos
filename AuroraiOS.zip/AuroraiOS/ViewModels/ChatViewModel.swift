import Foundation

@MainActor
final class ConversationListViewModel: ObservableObject {
    @Published var conversations: [Conversation] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let api = AuroraAPIClient.shared

    func load() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            conversations = try await api.getConversations()
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func createConversation() async -> Conversation? {
        do {
            let conv = try await api.createConversation()
            conversations.insert(conv, at: 0)
            return conv
        } catch {
            errorMessage = error.localizedDescription
            return nil
        }
    }

    func delete(_ conversation: Conversation) async {
        do {
            try await api.deleteConversation(conversationId: conversation.id)
            conversations.removeAll { $0.id == conversation.id }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func rename(_ conversation: Conversation, to title: String) async {
        do {
            try await api.renameConversation(conversationId: conversation.id, title: title)
            if let idx = conversations.firstIndex(where: { $0.id == conversation.id }) {
                conversations[idx].title = title
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

@MainActor
final class ChatViewModel: ObservableObject {
    let conversation: Conversation

    @Published var messages: [DisplayMessage] = []
    @Published var isLoadingHistory = false
    @Published var isSending = false
    @Published var errorMessage: String?
    @Published var selectedModel: AuroraModel = .aurora

    // Status pulled from stream events, shown as a small inline indicator
    // (e.g. "Running Python…", "Calling tool: search…").
    @Published var activityStatus: String?

    private let api = AuroraAPIClient.shared
    private var streamTask: Task<Void, Never>?

    init(conversation: Conversation) {
        self.conversation = conversation
    }

    func loadHistory() async {
        isLoadingHistory = true
        errorMessage = nil
        defer { isLoadingHistory = false }
        do {
            let dtos = try await api.getMessages(conversationId: conversation.id)
            messages = dtos.map { DisplayMessage(id: $0.id, role: $0.role, content: $0.content) }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func send(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isSending else { return }

        let userMsg = DisplayMessage(id: UUID().uuidString, role: "user", content: trimmed)
        let assistantMsgId = UUID().uuidString
        var assistantMsg = DisplayMessage(id: assistantMsgId, role: "assistant", content: "", isStreaming: true)
        messages.append(userMsg)
        messages.append(assistantMsg)

        isSending = true
        errorMessage = nil
        activityStatus = nil

        streamTask?.cancel()
        streamTask = Task {
            defer {
                isSending = false
                activityStatus = nil
                if let idx = messages.firstIndex(where: { $0.id == assistantMsgId }) {
                    messages[idx].isStreaming = false
                }
            }
            do {
                let stream = api.streamChat(conversationId: conversation.id, message: trimmed, model: selectedModel)
                for try await event in stream {
                    guard let idx = messages.firstIndex(where: { $0.id == assistantMsgId }) else { return }
                    if let delta = event.text {
                        messages[idx].content += delta
                        activityStatus = nil
                    }
                    if let toolCall = event.tool_call {
                        activityStatus = "Calling \(toolCall.name)…"
                    }
                    if event.tool_result != nil {
                        activityStatus = nil
                    }
                    if let codeRunning = event.code_running {
                        activityStatus = "Running \(codeRunning.language)…"
                    }
                    if let cmdRunning = event.cmd_running, !cmdRunning.commands.isEmpty {
                        activityStatus = "Running commands…"
                    }
                    if let err = event.error {
                        errorMessage = err
                    }
                    if event.done == true {
                        break
                    }
                }
                assistantMsg = messages.first(where: { $0.id == assistantMsgId }) ?? assistantMsg
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func cancelStreaming() {
        streamTask?.cancel()
        isSending = false
        activityStatus = nil
    }
}
