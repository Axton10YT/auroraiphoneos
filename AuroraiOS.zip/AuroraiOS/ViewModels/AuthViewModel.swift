import Foundation

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var isAuthenticated = false
    @Published var currentUser: AuroraUser?
    @Published var isLoading = false
    @Published var errorMessage: String?

    // Set when the server asks for a TOTP code mid-login.
    @Published var pendingMFAChallenge: String?

    private let api = AuroraAPIClient.shared

    /// Called once at app launch. If we have a saved token, verify it's
    /// still valid by hitting GET /user/me rather than trusting it blindly.
    func restoreSession() async {
        guard api.accessToken != nil else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            currentUser = try await api.getMe()
            isAuthenticated = true
        } catch {
            api.setToken(nil)
            isAuthenticated = false
        }
    }

    func login(email: String, password: String) async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let user = try await api.login(email: email, password: password)
            currentUser = user
            isAuthenticated = true
        } catch AuroraAPIError.mfaRequired(let challenge) {
            pendingMFAChallenge = challenge
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func submitMFACode(_ code: String) async {
        guard let challenge = pendingMFAChallenge else { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let user = try await api.verifyMFA(challengeToken: challenge, code: code)
            currentUser = user
            isAuthenticated = true
            pendingMFAChallenge = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func signup(email: String, password: String, displayName: String) async -> Bool {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            try await api.signup(email: email, password: password, displayName: displayName)
            return true // caller should tell the user to check their email
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func logout() async {
        await api.logout()
        currentUser = nil
        isAuthenticated = false
        pendingMFAChallenge = nil
    }
}
