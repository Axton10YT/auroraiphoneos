# Aurora for iOS

Native SwiftUI client for Aurora, built directly against the live `aurora-api`
Cloudflare Worker source (pulled via the Cloudflare Developer Platform MCP
connector, not guessed).

## Setup

1. In Xcode: **File → New → Project → iOS → App**. Name it `Aurora`,
   interface: SwiftUI, language: Swift. iOS 17+ target (uses `.onChange`
   two-param API, `NavigationStack`, `TextField(axis:)`).
2. Delete the generated `ContentView.swift` and default `AuroraApp.swift`.
3. Drag the `App/`, `Models/`, `Networking/`, `ViewModels/`, and `Views/`
   folders from this bundle into the project navigator (check
   "Copy items if needed" and add to your app target).
4. Build & run on a device/simulator running iOS 17+.

No third-party dependencies — pure Foundation/SwiftUI/Security.

## What's wired up

- Email/password signup + login, with email verification and TOTP MFA
  challenge handling
- JWT access token persisted in Keychain, session restored + re-validated
  (`GET /user/me`) on launch
- Conversation list (create / rename-ready model / delete)
- Real-time streamed chat via SSE (`POST /conversations/{id}/chat`), parsed
  byte-by-byte off `URLSession.bytes(for:)`
- Model picker (Aurora / Aurora Pro)
- Inline activity indicator for tool calls / code execution / shell commands
  mid-stream
- Settings sheet with account info and sign out

## API contract (verified against the deployed worker)

Base URL: `https://aurora.metalai.org/api`

| Endpoint | Method | Notes |
|---|---|---|
| `/auth/signup` | POST | `{email, password, display_name?}` → 201, sends verification email |
| `/auth/verify-email` | POST | `{token}` |
| `/auth/login` | POST | `{email, password}` → `{access_token, user}` or `{mfa_required, challenge_token}` |
| `/auth/mfa/verify` | POST | `{challenge_token, totp_code}` → `{access_token, user}` |
| `/auth/logout` | POST | revokes session |
| `/user/me` | GET | `{user: {...}}` |
| `/conversations` | GET/POST | list / create |
| `/conversations/{id}` | GET/PUT/DELETE | messages / rename / delete |
| `/conversations/{id}/chat` | POST | `{message, model, files?}` → **SSE stream** |
| `/v1/models` | GET | `["aurora", "aurora-pro"]` |

Auth header: `Authorization: Bearer <JWT>` for user sessions, or
`Bearer aur_...` for API keys (not used by this app — that's the developer
console's job).

### SSE event shapes (`data: {...}\n\n`)

```
{ "text": "..." }                          // content delta
{ "tool_call": { "name": "..." } }
{ "tool_result": { "name": "...", "result": "..." } }
{ "code_running": { "language": "python" } }
{ "cmd_running": { "commands": [...] } }
{ "done": true, "message_id": "..." }
{ "error": "..." }
```

## Not yet built (worth a follow-up pass)

- File/image attachments (`files` field is supported server-side, no UI yet)
- MCP tool management (`/dev/mcp*`) — dev console already covers this on web
- Memory settings UI (`/user/memory*`)
- Session management (`/auth/sessions*`)
- The old placeholder `AuroraApp.swift` written before the worker review was
  replaced — this bundle's `App/AuroraApp.swift` is the current one, ignore
  anything mentioned earlier in chat.
