import SwiftUI

struct MessageBubble: View {
    let message: DisplayMessage

    var body: some View {
        HStack {
            if message.isUser { Spacer(minLength: 40) }

            VStack(alignment: .leading, spacing: 4) {
                if message.content.isEmpty && message.isStreaming {
                    TypingDots()
                } else {
                    Text(message.content)
                        .font(.body)
                        .foregroundStyle(message.isUser ? .white : .primary)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(message.isUser ? Color.accentColor : Color(.secondarySystemBackground))
            )

            if !message.isUser { Spacer(minLength: 40) }
        }
    }
}

/// Small animated "···" shown while waiting for the first token.
private struct TypingDots: View {
    @State private var phase = 0

    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .frame(width: 6, height: 6)
                    .opacity(phase == i ? 1 : 0.3)
            }
        }
        .onAppear {
            Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true) { _ in
                phase = (phase + 1) % 3
            }
        }
    }
}
