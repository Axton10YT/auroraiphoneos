import Foundation

// MARK: - User

struct AuroraUser: Codable, Identifiable {
    let id: String
    let email: String
    let display_name: String
    let email_verified: Bool
    let totp_enabled: Bool
    let memory_mode: String?
    let memory_enabled: Bool?
    let created_at: String
}

// MARK: - Conversation

struct Conversation: Codable, Identifiable, Hashable {
    let id: String
    var title: String
    let created_at: String
    var updated_at: String
}

// MARK: - Message

struct ChatMessageDTO: Codable, Identifiable, Hashable {
    let id: String
    let role: String // "user" | "assistant"
    let content: String
    let created_at: String
}

/// Local, mutable message used while streaming a reply.
struct DisplayMessage: Identifiable, Hashable {
    let id: String
    let role: String
    var content: String
    var isStreaming: Bool = false

    var isUser: Bool { role == "user" }
}

// MARK: - Model picker (from GET /v1/models)

enum AuroraModel: String, CaseIterable, Identifiable {
    case aurora = "aurora"
    case auroraPro = "aurora-pro"
    var id: String { rawValue }
    var displayName: String {
        switch self {
        case .aurora: return "Aurora"
        case .auroraPro: return "Aurora Pro"
        }
    }
}

// MARK: - Auth responses

struct LoginResponse: Codable {
    let access_token: String?
    let user: AuroraUser?
    let mfa_required: Bool?
    let challenge_token: String?
}

struct APIErrorResponse: Codable {
    let error: String?
}

// MARK: - SSE stream events from POST /conversations/{id}/chat
// Server sends `data: {...}\n\n` lines. Each payload is one of these shapes;
// we decode into a loose struct and branch on which keys are present.

struct ChatStreamEvent: Codable {
    let text: String?
    let done: Bool?
    let message_id: String?
    let error: String?
    let tool_call: ToolCallEvent?
    let tool_result: ToolResultEvent?
    let code_running: CodeRunningEvent?
    let cmd_running: CmdRunningEvent?
}

struct ToolCallEvent: Codable {
    let name: String
    // args is a free-form JSON object server-side; we don't need to render it precisely.
}

struct ToolResultEvent: Codable {
    let name: String
    let result: String
}

struct CodeRunningEvent: Codable {
    let language: String
}

struct CmdRunningEvent: Codable {
    let commands: [String]
}
