import Foundation

enum AuroraAPIError: LocalizedError {
    case server(String)
    case mfaRequired(challengeToken: String)
    case decoding
    case notAuthenticated

    var errorDescription: String? {
        switch self {
        case .server(let msg): return msg
        case .mfaRequired: return "Two-factor code required"
        case .decoding: return "Couldn't understand the server's response"
        case .notAuthenticated: return "Not signed in"
        }
    }
}

/// Talks to the real aurora-api Cloudflare Worker.
/// Base path: everything is mounted under /api on aurora.metalai.org,
/// and the worker itself strips the /api prefix internally.
final class AuroraAPIClient {
    static let shared = AuroraAPIClient()

    private let baseURL = URL(string: "https://aurora.metalai.org/api")!
    private let session: URLSession
    private let tokenKey = "aurora_access_token"

    private(set) var accessToken: String? {
        didSet {
            if let accessToken {
                KeychainHelper.save(accessToken, key: tokenKey)
            } else {
                KeychainHelper.delete(key: tokenKey)
            }
        }
    }

    private init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        session = URLSession(configuration: config)
        accessToken = KeychainHelper.read(key: tokenKey)
    }

    func setToken(_ token: String?) {
        accessToken = token
    }

    // MARK: - Request building

    private func request(_ path: String, method: String = "GET", body: [String: Any]? = nil) throws -> URLRequest {
        var req = URLRequest(url: baseURL.appendingPathComponent(path))
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let accessToken {
            req.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        }
        if let body {
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        return req
    }

    private func send(_ req: URLRequest) async throws -> Data {
        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw AuroraAPIError.decoding }
        if !(200...299).contains(http.statusCode) {
            if let apiErr = try? JSONDecoder().decode(APIErrorResponse.self, from: data), let msg = apiErr.error {
                throw AuroraAPIError.server(msg)
            }
            throw AuroraAPIError.server("Request failed (\(http.statusCode))")
        }
        return data
    }

    // MARK: - Auth

    /// POST /auth/signup
    func signup(email: String, password: String, displayName: String?) async throws {
        var body: [String: Any] = ["email": email, "password": password]
        if let displayName, !displayName.isEmpty { body["display_name"] = displayName }
        let req = try request("/auth/signup", method: "POST", body: body)
        _ = try await send(req)
    }

    /// POST /auth/login — returns either a session (access_token+user) or an MFA challenge.
    func login(email: String, password: String) async throws -> AuroraUser {
        let req = try request("/auth/login", method: "POST", body: ["email": email, "password": password])
        let data = try await send(req)
        let decoded = try JSONDecoder().decode(LoginResponse.self, from: data)
        if decoded.mfa_required == true, let challenge = decoded.challenge_token {
            throw AuroraAPIError.mfaRequired(challengeToken: challenge)
        }
        guard let token = decoded.access_token, let user = decoded.user else {
            throw AuroraAPIError.decoding
        }
        setToken(token)
        return user
    }

    /// POST /auth/mfa/verify
    func verifyMFA(challengeToken: String, code: String) async throws -> AuroraUser {
        let req = try request("/auth/mfa/verify", method: "POST", body: [
            "challenge_token": challengeToken,
            "totp_code": code
        ])
        let data = try await send(req)
        let decoded = try JSONDecoder().decode(LoginResponse.self, from: data)
        guard let token = decoded.access_token, let user = decoded.user else {
            throw AuroraAPIError.decoding
        }
        setToken(token)
        return user
    }

    /// POST /auth/logout
    func logout() async {
        if let req = try? request("/auth/logout", method: "POST") {
            _ = try? await send(req)
        }
        setToken(nil)
    }

    /// GET /user/me
    func getMe() async throws -> AuroraUser {
        let req = try request("/user/me")
        let data = try await send(req)
        struct Wrapper: Codable { let user: AuroraUser }
        return try JSONDecoder().decode(Wrapper.self, from: data).user
    }

    // MARK: - Conversations

    /// GET /conversations
    func getConversations() async throws -> [Conversation] {
        let req = try request("/conversations")
        let data = try await send(req)
        struct Wrapper: Codable { let conversations: [Conversation] }
        return try JSONDecoder().decode(Wrapper.self, from: data).conversations
    }

    /// POST /conversations
    func createConversation(title: String? = nil) async throws -> Conversation {
        let body: [String: Any] = title.map { ["title": $0] } ?? [:]
        let req = try request("/conversations", method: "POST", body: body)
        let data = try await send(req)
        return try JSONDecoder().decode(Conversation.self, from: data)
    }

    /// GET /conversations/{id}
    func getMessages(conversationId: String) async throws -> [ChatMessageDTO] {
        let req = try request("/conversations/\(conversationId)")
        let data = try await send(req)
        struct Wrapper: Codable { let messages: [ChatMessageDTO] }
        return try JSONDecoder().decode(Wrapper.self, from: data).messages
    }

    /// PUT /conversations/{id}
    func renameConversation(conversationId: String, title: String) async throws {
        let req = try request("/conversations/\(conversationId)", method: "PUT", body: ["title": title])
        _ = try await send(req)
    }

    /// DELETE /conversations/{id}
    func deleteConversation(conversationId: String) async throws {
        let req = try request("/conversations/\(conversationId)", method: "DELETE")
        _ = try await send(req)
    }

    // MARK: - Chat streaming (SSE)

    /// POST /conversations/{id}/chat
    /// The worker responds with `Content-Type: text/event-stream`, one JSON
    /// payload per `data: {...}\n\n` line. We parse it live with URLSession's
    /// byte stream and yield decoded events as they arrive.
    func streamChat(conversationId: String, message: String, model: AuroraModel) -> AsyncThrowingStream<ChatStreamEvent, Error> {
        AsyncThrowingStream { continuation in
            let task = Task {
                do {
                    var req = try request("/conversations/\(conversationId)/chat", method: "POST", body: [
                        "message": message,
                        "model": model.rawValue
                    ])
                    req.setValue("text/event-stream", forHTTPHeaderField: "Accept")

                    let (bytes, response) = try await session.bytes(for: req)
                    if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                        continuation.finish(throwing: AuroraAPIError.server("Chat request failed (\(http.statusCode))"))
                        return
                    }

                    var lineBuffer = ""
                    for try await byte in bytes {
                        guard let scalar = Unicode.Scalar(byte) else { continue }
                        let char = Character(scalar)
                        if char == "\n" {
                            let line = lineBuffer
                            lineBuffer = ""
                            guard line.hasPrefix("data: ") else { continue }
                            let payload = String(line.dropFirst(6))
                            if payload == "[DONE]" { continue }
                            guard let payloadData = payload.data(using: .utf8) else { continue }
                            if let event = try? JSONDecoder().decode(ChatStreamEvent.self, from: payloadData) {
                                continuation.yield(event)
                                if event.done == true || event.error != nil {
                                    continuation.finish()
                                    return
                                }
                            }
                        } else {
                            lineBuffer.append(char)
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }
}
