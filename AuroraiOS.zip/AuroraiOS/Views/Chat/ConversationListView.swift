import SwiftUI

struct ConversationListView: View {
    @EnvironmentObject var auth: AuthViewModel
    @StateObject private var listVM = ConversationListViewModel()
    @State private var showSettings = false
    @State private var navigateTo: Conversation?

    var body: some View {
        NavigationStack {
            Group {
                if listVM.isLoading && listVM.conversations.isEmpty {
                    ProgressView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if listVM.conversations.isEmpty {
                    emptyState
                } else {
                    List {
                        ForEach(listVM.conversations) { conversation in
                            NavigationLink(value: conversation) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(conversation.title)
                                        .font(.body)
                                        .lineLimit(1)
                                    Text(conversation.updated_at)
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                        .onDelete { indexSet in
                            Task {
                                for index in indexSet {
                                    await listVM.delete(listVM.conversations[index])
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Aurora")
            .navigationDestination(for: Conversation.self) { conversation in
                ChatView(conversation: conversation)
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        showSettings = true
                    } label: {
                        Image(systemName: "gearshape")
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task {
                            if let conv = await listVM.createConversation() {
                                navigateTo = conv
                            }
                        }
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                }
            }
            .navigationDestination(item: $navigateTo) { conversation in
                ChatView(conversation: conversation)
            }
            .sheet(isPresented: $showSettings) {
                SettingsView().environmentObject(auth)
            }
            .task {
                await listVM.load()
            }
            .refreshable {
                await listVM.load()
            }
            .alert("Error", isPresented: .constant(listVM.errorMessage != nil)) {
                Button("OK") { listVM.errorMessage = nil }
            } message: {
                Text(listVM.errorMessage ?? "")
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "sparkles")
                .font(.system(size: 40))
                .foregroundStyle(.secondary)
            Text("No conversations yet")
                .font(.headline)
            Button("Start a new chat") {
                Task {
                    if let conv = await listVM.createConversation() {
                        navigateTo = conv
                    }
                }
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
